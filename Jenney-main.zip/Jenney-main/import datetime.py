import datetime

# Create a list to store the recently performed tasks
recent_tasks = []

# Function to add a task to the list
def add_task(task):
    timestamp = datetime.datetime.now()
    recent_tasks.append((timestamp, task))

# Function to generate the report of recently performed tasks
def generate_report():
    report = "Recently Performed Tasks\n\n"
    for task in recent_tasks:
        timestamp, task_name = task
        formatted_timestamp = timestamp.strftime("%Y-%m-%d %H:%M:%S")
        report += f"{formatted_timestamp}: {task_name}\n"
    return report

# Example usage: Adding tasks to the list
add_task("Task 1")
add_task("Task 2")
add_task("Task 3")

# Generating and printing the report
report = generate_report()
print(report)
